package com.Spring.services;

import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.Spring.repositories.UserRepo;
import com.Spring.models.User;


@Service
public class UserService 
{
	@Autowired
	UserRepo usr;
	
		
	public boolean checkuser(User u)
	{
		User us = usr.findAll().stream()
		.filter(m->m.getUsername().toLowerCase().equals(u.getUsername().toLowerCase()))
		.collect(Collectors.toList()).get(0);
		
		if(us!=null)
			return true;
		else
			return false;		
	}
}