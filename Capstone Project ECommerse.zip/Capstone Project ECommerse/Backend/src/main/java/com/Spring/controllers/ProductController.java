package com.Spring.controllers;


import java.io.IOException;
import java.io.InputStream;
import java.sql.Blob;
import java.sql.SQLException;
import java.util.List;

import javax.sql.rowset.serial.SerialBlob;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestPart;

import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.Spring.models.Product;
import com.Spring.services.ProductService;

@RestController
@RequestMapping("product")
@CrossOrigin(origins = "*",allowedHeaders="*")
public class ProductController 
{
	@Autowired
	ProductService prdtserv;
	
	
	
	@GetMapping("prdlist")
	@CrossOrigin(origins="http:/localhost/4200/")
	public List<Product> getList()
	{		
		return prdtserv.prdtList();
	
	}
	
	
	@PostMapping("addprdt")
	@CrossOrigin(origins="http:/localhost:4200/")
	public String add(@RequestPart("data") Product pt,@RequestPart("pic")  MultipartFile pic)	
	{		
		try {				
			pt.setPic(pic.getBytes());					
		} 
		catch (IOException e) {			
			e.printStackTrace();
		}
		
		prdtserv.addProduct(pt);
		
		
		return "Record is added !";
		
	}
	
	
	@DeleteMapping("delprdt/{id}")
	//@CrossOrigin(origins="http:/localhost/4200/")
	public  String delRec(@PathVariable("id") int id )
	{
		prdtserv.deleteById(id);
		return "record deleted";
	}

	
	@PutMapping("update")
	//CrossOrigin(origins="http:/localhost/4200/")
	public String updateRec(@RequestBody Product ct)
	{
		prdtserv.updateProduct(ct);
		return "Record updated";
	}
	

}