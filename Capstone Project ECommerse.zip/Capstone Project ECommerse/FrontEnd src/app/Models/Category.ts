export class Category{

    catid:number = 0;
    catnm:string='';
}