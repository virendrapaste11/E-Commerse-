import { CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserheaderComponent } from './user/userheader/userheader.component';
import { UserloginComponent } from './user/userlogin/userlogin.component';
import { FormsModule } from '@angular/forms';
import { RouterModule } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { DashboardpgComponent } from './dashboard/dashboardpg/dashboardpg.component';
import { provideAnimationsAsync } from '@angular/platform-browser/animations/async';
import { MatToolbarModule} from '@angular/material/toolbar';
import {MatIconModule} from '@angular/material/icon';
import {MatButtonModule} from '@angular/material/button';
import { CustomerpgComponent } from './customer/customerpg/customerpg.component';
import { CustomeritemsComponent } from './customer/customeritems/customeritems.component';
import { MatTooltipModule} from '@angular/material/tooltip';
import { MatMenuModule, MatMenuTrigger } from '@angular/material/menu';

@NgModule({
  declarations: [
    AppComponent,
    UserheaderComponent,
    UserloginComponent,
    DashboardpgComponent,
    CustomerpgComponent,
    CustomeritemsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,MatToolbarModule,MatIconModule,MatButtonModule,MatTooltipModule,MatMenuTrigger,MatMenuModule,
    RouterModule.forRoot([
      { path:"user", component:UserloginComponent},
      { path:"",redirectTo:"user",pathMatch:"full"},
      { path:"dashboard", component:DashboardpgComponent}

    ])
  ],
  providers: [
    provideAnimationsAsync()
  ],
  bootstrap: [AppComponent],

  schemas:[CUSTOM_ELEMENTS_SCHEMA,NO_ERRORS_SCHEMA]
})
export class AppModule { }
