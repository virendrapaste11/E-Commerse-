import { Component } from '@angular/core';
import { CustomService } from '../../../services/custom.service';
import { Product } from '../../Models/Product';
import { Category } from '../../Models/Category';

@Component({
  selector: 'app-customerpg',
  templateUrl: './customerpg.component.html',
  styleUrl: './customerpg.component.css'
})
export class CustomerpgComponent {


  obj:Product []=[]
  catobj:Category[]=[]
 catno:number=0

 prdt:Product []=[]



 
constructor(private customserv:CustomService){


   this.customserv.getallproducts().subscribe(
     res=>{
       this.obj = res;
       this.customserv.filterobj=res;
     },
     err=>console.log(err)
     )


 this.customserv.getallcategory().subscribe(
     res=>{
       this.customserv.allcatobj = res
       this.catobj = res

     },
     err=>console.log(err)
     )
 }

 ngDoCheck()
   {
    this.customserv.filterobj=this.obj.filter(m=>m.ct["catid"]==this.catno)
   }

   catnovalue(val:any)
   {
    this.catno = val;
   }
}
