import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CustomeritemsComponent } from './customeritems.component';

describe('CustomeritemsComponent', () => {
  let component: CustomeritemsComponent;
  let fixture: ComponentFixture<CustomeritemsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CustomeritemsComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(CustomeritemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
