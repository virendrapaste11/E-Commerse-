import { Component } from '@angular/core';
import { CustomService } from '../../../services/custom.service';

@Component({
  selector: 'app-customeritems',
  templateUrl: './customeritems.component.html',
  styleUrl: './customeritems.component.css'
})
export class CustomeritemsComponent {

  pt: any



  tempform = {prnm :'',price:'',qty:'',pic:Blob , desc:'',ct:null}

constructor(private lgserv: CustomService)
{
  this.pt = this.lgserv.filterobj

}

ngDoCheck()
{
  this.pt = this.lgserv.filterobj

}


addtolocalstorage(a?:any)
{
  console.log(a);
  sessionStorage.setItem(a.prnm,JSON.stringify(a));
}

}
