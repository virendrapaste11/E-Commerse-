// import { Component } from '@angular/core';
// import { FormsModule } from '@angular/forms';


// @Component({
//   selector: 'app-userlogin',
//   templateUrl: './userlogin.component.html',
//   styleUrl: './userlogin.component.css'
// })
// export class UserloginComponent {



//   onSubmit() {
//     // Add authentication logic here
//     console.log('Login clicked');
//     console.log('Username: ', this.username);
//     console.log('Password: ', this.password);
// }
// }

import { Component } from '@angular/core';
import { CustomService } from '../../../services/custom.service';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-adminlogin',
  templateUrl: './userlogin.component.html',
  styleUrl: './userlogin.component.css'
})
export class UserloginComponent {

  username: string = '';
  password: string = '';



  constructor(private customserv:CustomService,private route:Router){}

  onSubmit(){

    let obj={id:0,username:this.username,password:this.password}

    this.customserv.userexist(obj).subscribe(
      response =>{
        console.log(response)
        if(response)
        {
          this.route.navigate(["/dashboard"])
        }
      },
      error=> console.log(error)
    );
  }





}
function subscribe(arg0: (response: any) => void, arg1: (error: any) => void) {
  throw new Error('Function not implemented.');
}

