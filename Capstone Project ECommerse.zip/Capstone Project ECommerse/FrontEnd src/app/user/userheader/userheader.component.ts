import { Component, ViewChild } from '@angular/core';
import { CustomService } from '../../../services/custom.service';
import { Router } from '@angular/router';
import { MatMenuTrigger } from '@angular/material/menu';



@Component({
  selector: 'app-userheader',
  templateUrl: './userheader.component.html',
  styleUrl: './userheader.component.css'
})
export class UserheaderComponent {

  cart:any[]=[];
  tot=0;
  options:any;

 

  constructor(private customserv:CustomService,private route:Router){}
  login(){
    this.route.navigate(["/user"])
  }

  logout()
  {
    this.route.navigate(["/user"])
  }
order(){
  alert("Your Order Is Booked !");
}
  showcart()
    {
      let obj={};
      this.tot=0;
      this.cart=[];

      for(var i=0;i<sessionStorage.length;++i)
      {
        var key = sessionStorage.key(i);
        var val = sessionStorage.getItem(key);

        //console.log(key+':'+value);

        obj=JSON.parse(val)
        this.tot +=obj["price"]
        this.cart.push(obj);
      }
    }


    deletecart(a:any)
    {
      let obj={}
      this.tot=0;
      let index = this.cart.indexOf(a);

      this.cart.splice(index,1)
      //first delete existing list

      sessionStorage.removeItem(a.prnm);

      for(var i=0;i<sessionStorage.length;++i)
      {
        var key = sessionStorage.key(i);
        var value = sessionStorage.getItem(key);
        obj = JSON.parse(value)
        this.tot += obj["price"]
      }

    }
   
}