import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { User } from '../app/Models/User';
import { Product } from '../app/Models/Product';
import { Observable } from 'rxjs';
import { Category } from '../app/Models/Category';

@Injectable({
  providedIn: 'root'
})
export class CustomService {

    public filterobj:Product[]=[]
    public allcatobj:Category[]=[]

    constructor(private http:HttpClient) { }

  userexist(data:User)
  {
      return this.http.post("http://localhost:8080/user/checkuser",data)
  }

  getallproducts():Observable<Product[]>
  {
    return this.http.get<Product[]>("http://localhost:8080/product/prdlist")
  }

  getallcategory():Observable<Category[]>
  {
    return this.http.get<Category[]>("http://localhost:8080/category/catlist")
  }

  
}
